console.log("hello")
const usernamefield = document.querySelector("#usernamefield");

usernamefield.addEventListener("keyup", (event) => {
    console.log("7777777", 7777777)
    const usernamevalue = event.target.value;
    console.log("usernameval",usernamevalue)
        
})